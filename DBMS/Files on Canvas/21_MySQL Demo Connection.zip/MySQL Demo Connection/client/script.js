document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch('http://localhost:4000/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `email=${email}&password=${password}`
    })
    .then(response => response.text())
    .then(data => {
        if (data === 'User registered successfully') {
            // Success case
            document.getElementById('response').innerText = data;
            
            // Clear the form after successful submission
            document.getElementById('registrationForm').reset();
        } else {
            // Show error message if email is already registered
            document.getElementById('response').innerText = data;
        }

        // Optionally hide the message after 3 seconds
        setTimeout(() => {
            document.getElementById('response').innerText = '';
        }, 3000);
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('response').innerText = 'Error registering user!';
    });
});
