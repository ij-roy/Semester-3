const express = require('express');
const mysql = require('mysql2'); // Use mysql2 instead of mysql
const bodyParser = require('body-parser');
const cors = require('cors'); // Import CORS middleware
const app = express();
const port = 4000;

// Enable CORS for all routes
app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // Allow JSON parsing for better API handling

// MySQL connection setup using mysql2
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'your_password',  // Use your MySQL password here
    database: 'your_db_name'       // Use your database name here
});

// Connect to MySQL
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL!');
});

// Registration route
app.post('/register', (req, res) => {
    const { email, password } = req.body;

    // Check if email already exists in the database
    const checkEmailQuery = 'SELECT * FROM users WHERE email = ?';
    connection.query(checkEmailQuery, [email], (err, results) => {
        if (err) {
            console.error('Error querying the database:', err);
            res.status(500).send('Server error');
            return;
        }

        if (results.length > 0) {
            // If the email is found in the database, respond with an error message
            res.status(400).send('Email already registered');
        } else {
            // Insert new user if email doesn't exist
            const insertUserQuery = 'INSERT INTO users (email, password) VALUES (?, ?)';
            connection.query(insertUserQuery, [email, password], (err, result) => {
                if (err) {
                    console.error('Error inserting into the database:', err);
                    res.status(500).send('Server error');
                } else {
                    res.status(200).send('User registered successfully');
                }
            });
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
});
